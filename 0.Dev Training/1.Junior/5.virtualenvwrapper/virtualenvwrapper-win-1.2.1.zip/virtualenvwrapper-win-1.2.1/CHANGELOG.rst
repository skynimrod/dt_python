Version 1.2.0 (16-03-2015)
=====================================

Thanks to Christian Long (@christianmlong)
*   ``mkvirtualenv`` hooks
